package com.project1_frontend.model;

import java.io.Serializable;

	public class UserModel implements Serializable {

		private static final long serialVersionUID = 1L;
		
		private int id;
		private String fullName;
		private String role;
		private Cart cart;
		
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		
		
		
		public int getId() {
			return id;
		}
		@Override
		public String toString() {
			return "UserModel [id=" + id + ", fullName=" + fullName + ", role=" + role + ", cart=" + cart + "]";
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getFullName() {
			return fullName;
		}
		public void setFullName(String fullName) {
			this.fullName = fullName;
		}
		public Cart getCart() {
			return cart;
		}
		public void setCart(Cart cart) {
			this.cart = cart;
		}
			
	}