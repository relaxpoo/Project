package com.project1_frontend.test;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.project1_frontend.Dao.CategoryDao;
import com.project1_frontend.model.Category;




public class CategoryTestCase {

	
		private static AnnotationConfigApplicationContext context;
		
		
		private static CategoryDao categoryDao;
		
		
		private Category category;
		
		
		@BeforeClass
		public static void init() {
			context = new AnnotationConfigApplicationContext();
			context.scan("project1_frontend");
			context.refresh();
			categoryDao = (CategoryDao)context.getBean("categoryDao");
		}
		
		@Test
		public void testAddCategory() {
			category = new Category();

			category.setCategoryname("Tops & Tshirts");
			assertEquals("Added a category successfully!",true,categoryDao.add(category));	
		
			
		}
		
		
	}



