package com.project1_frontend.Dao;

import java.util.List;

import com.project1_frontend.model.Category;

public interface CategoryDao {
	
	List<Category> list();

}
