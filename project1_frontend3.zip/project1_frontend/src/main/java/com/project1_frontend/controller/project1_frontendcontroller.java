package com.project1_frontend.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.project1_frontend.Dao.CategoryDao;


@Controller
public class project1_frontendcontroller {

	@Autowired
	private CategoryDao categoryDao;
	
	private static final Logger logger = LoggerFactory.getLogger(project1_frontendcontroller.class);

	@RequestMapping(value= {"/" , "/home" , "/index"})
	public ModelAndView home() {
		ModelAndView mv = new ModelAndView("masterpage");
		mv.addObject("title", "Home");
		
		logger.info("Inside project1_frontendcontroller index method - INFO");
		logger.debug("Inside project1_frontendcontroller index method - DEBUG");
		
		// passing the list of categories
		mv.addObject("categories", categoryDao.list());
		mv.addObject("userClickHome", true);
		return mv;
	}

	@RequestMapping(value= "/contactus")
	public ModelAndView contact() {
		ModelAndView mv = new ModelAndView("masterpage");
		mv.addObject("title", "ContactUs");
		mv.addObject("userClickContactUs", true);
		return mv;
	}

	@RequestMapping(value= "/aboutus")
	public ModelAndView about() {
		ModelAndView mv = new ModelAndView("masterpage");
		mv.addObject("title", "AboutUs");
		mv.addObject("userClickAboutUs", true);
		return mv;
	}
 


}
