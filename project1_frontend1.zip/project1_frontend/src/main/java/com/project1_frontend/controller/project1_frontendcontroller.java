package com.project1_frontend.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.project1_frontend.Service.CustomerService;
import com.project1_frontend.Service.ProductServices;
import com.project1_frontend.model.Customer;

@Controller
public class project1_frontendcontroller {
	
	@Autowired
	CustomerService customerservice;
	@Autowired
	ProductServices productservices;
	
	@RequestMapping("/")
	public String home(Model model)
	{
		model.addAttribute("message","Hello I am alive.");
		return "home";
			
	}
	@RequestMapping("/aboutus")
	public String aboutUs()
	{
		return "aboutUs";
	}
	@RequestMapping("/productlist")
	public String productlist(Model model)
	{
		return "Product";
	}
	
	
	@RequestMapping(value="/home")
	public String homePage(HttpSession session){
			session.setAttribute("categories", productservices.getAllCategories());
		return "home";//logical view name
	}

	//for logout -> /login?logout=''
	//for invalid credentials -> /login?error=''
	@RequestMapping("/SignIn")
	public String loginPage(@RequestParam(required=false) String error,@RequestParam(required=false) String logout,Model model){
		if(error!=null)
		model.addAttribute("error","Invalid Username/Password");
		if(logout!=null)
			model.addAttribute("msg","Loggedout successfully");
		return "SignIn";
	}
}
